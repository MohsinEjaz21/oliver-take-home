
import get from './get';
import post from './post';

export const axios = { get, post };