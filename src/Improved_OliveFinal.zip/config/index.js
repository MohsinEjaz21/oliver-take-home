import env from "./config.json";

export const config = env;
